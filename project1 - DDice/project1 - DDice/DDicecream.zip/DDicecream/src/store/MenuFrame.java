package store;
import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;


public class MenuFrame {  //JLabel

	
	public void create() {
		JFrame menuFrame = new JFrame();
		menuFrame.setTitle("menu");
		menuFrame.setSize(815,620);  
		menuFrame.setLocation(500, 90);
		menuFrame.setResizable(false);
		menuFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	
		JPanel menuPanel = createMenuPanel();
		menuFrame.add(menuPanel);
		menuFrame.setVisible(true);
		
	}
	
	private JPanel createMenuPanel(IceInfo[] iceInfos) {
		JPanel menuPanel = new JPanel();
		menuPanel.setBackground(Color.WHITE);
		for(int i = 0; i < iceInfos.length; i++) {
			JLabel jlIceName = new JLabel(iceInfos[i].name);
			jlIceName.setFont(new Font("맑은고딕", Font.BOLD, 15));
//			JLabel jlIcePrcie = new JLabel(iceInfos[i].changePrice(i));
//			jlIcePrice.setFont(new Font("맑은고딕", Font.BOLD, 15));
//			
//			menuPanel.add(jlIcePrcie);
			menuPanel.add(jlIceName);
		}

		return menuPanel;
	}
}
package store;

public class IceKind {
	//static final = 상수 : 변하지 않는 값
	public static final String BAR = "바";
	public static final String CON = "콘";
	public static final String CUP = "겁";

}

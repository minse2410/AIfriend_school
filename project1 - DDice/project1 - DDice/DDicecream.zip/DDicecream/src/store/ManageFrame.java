package store;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.WindowConstants;

public class ManageFrame {

	private JFrame manageFrame;
	private JPanel cards;
	private CardLayout cardLayout;

	public void create() {
		manageFrame = new JFrame();
		manageFrame.setTitle("manage");
		manageFrame.setSize(500, 350);
		manageFrame.setLocation(660, 450);
		manageFrame.setResizable(false);
		manageFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		cardLayout = new CardLayout();
		cards = new JPanel(cardLayout);

		JPanel managePs = createManagePanel();
		cards.add(managePs, "checkPs");

		JPanel managePanel = createmanagePanel();
		cards.add(managePanel, "manage");

		JPanel setPricePanel = createSetPricePanel();
		cards.add(setPricePanel, "setPrice");

		JPanel addMenuPanel = createAddMenuPanel();
		cards.add(addMenuPanel, "addMenu");

		cardLayout.show(cards, "checkPs");
		manageFrame.setVisible(true);
		manageFrame.add(cards);

	}

	//
	private JPanel createManagePanel() {
		JPanel managePsPanel = new JPanel();
		managePsPanel.setBackground(Color.WHITE);
		String ps = "1111";

		TextField psInput = new TextField(10);
		psInput.setFont(new Font("", Font.BOLD, 15));

		JButton checkPsButton = new JButton("확인");
		checkPsButton.setBackground(Color.WHITE);
		checkPsButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		checkPsButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				cardLayout.show(cards, "manage");

			}
		});

		managePsPanel.add(psInput);
		managePsPanel.add(checkPsButton);
//		managePsPanel.add();

		return managePsPanel;
	}

	// 변경 선택 panel
	private JPanel createmanagePanel() {
		JPanel managePanel = new JPanel();
		managePanel.setBackground(Color.WHITE);

		JButton setPriceButton = new JButton("가격변경");
		setPriceButton.setBackground(Color.WHITE);
		setPriceButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		setPriceButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				cardLayout.show(cards, "setPrice");

			}
		});

		JButton addMenuButton = new JButton("메뉴추가");
		addMenuButton.setBackground(Color.WHITE);
		addMenuButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		addMenuButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				cardLayout.show(cards, "addMenu");

			}
		});

		managePanel.add(setPriceButton);
		managePanel.add(addMenuButton);

		return managePanel;
	}

	// 가격변경 panel
	private JPanel createSetPricePanel() {
		JPanel setPricePanel = new JPanel();
		setPricePanel.setBackground(Color.WHITE);

		// 바 가격 변경 선택
		JButton setBarPriceButton = new JButton("Bar가격 변경");
		setBarPriceButton.setBackground(Color.WHITE);
		setBarPriceButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		setBarPriceButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		// 콘 가격 변경 선택
		JButton setConPriceButton = new JButton("Con가격 변경");
		setConPriceButton.setBackground(Color.WHITE);
		setConPriceButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		setConPriceButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		// 컵 가격 변경 선택
		JButton setCupPriceButton = new JButton("Cup가격 변경");
		setCupPriceButton.setBackground(Color.WHITE);
		setCupPriceButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		setCupPriceButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		// 가격 입력 칸
		JLabel jl1 = new JLabel("변경할 가격 입력 : ");
		jl1.setFont(new Font("맑은고딕", Font.BOLD, 15));
		TextField tfNewIcePrice = new TextField(10);
		tfNewIcePrice.setFont(new Font("맑은고딕", Font.BOLD, 15));

		// 추가 완료 버튼
		JButton finishSetPrice = new JButton("가격 변경");
		finishSetPrice.setBackground(Color.WHITE);
		finishSetPrice.setFont(new Font("맑은고딕", Font.BOLD, 15));

		finishSetPrice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// 창 띄움
				JOptionPane.showMessageDialog(setPricePanel, "가격 변경 완료.", "", JOptionPane.OK_OPTION);
			}
		});

		setPricePanel.add(setBarPriceButton);
		setPricePanel.add(setConPriceButton);
		setPricePanel.add(setCupPriceButton);
		setPricePanel.add(jl1);
		setPricePanel.add(tfNewIcePrice);
		setPricePanel.add(finishSetPrice);

		return setPricePanel;
	}

	// 메뉴 추가 panel
	private JPanel createAddMenuPanel() {
		JPanel addMenuPanel = new JPanel();
		addMenuPanel.setBackground(Color.WHITE);

		// 바 종류 변경 선택
		JButton chooseBarButton = new JButton("Bar종류");
		chooseBarButton.setBackground(Color.WHITE);
		chooseBarButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		chooseBarButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		// 콘 종류 변경 선택
		JButton chooseConButton = new JButton("Con종류");
		chooseConButton.setBackground(Color.WHITE);
		chooseConButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		chooseConButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		// 컵 종류 변경 선택 버튼
		JButton chooseCupButton = new JButton("Cup종류");
		chooseCupButton.setBackground(Color.WHITE);
		chooseCupButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		chooseCupButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		JButton chooseChocoButton = new JButton("초코맛 추가");
		chooseChocoButton.setBackground(Color.WHITE);
		chooseChocoButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		chooseChocoButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		JButton chooseStrawButton = new JButton("딸기맛 추가");
		chooseStrawButton.setBackground(Color.WHITE);
		chooseStrawButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		chooseStrawButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		JButton chooseGreenButton = new JButton("녹차맛 추가");
		chooseGreenButton.setBackground(Color.WHITE);
		chooseGreenButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		chooseGreenButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		JButton chooseBananaButton = new JButton("바나나맛 추가");
		chooseBananaButton.setBackground(Color.WHITE);
		chooseBananaButton.setFont(new Font("맑은고딕", Font.BOLD, 15));

		chooseBananaButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		// 메뉴 입력칸(메뉴 이름 : 이름 입력)
		JLabel jl1 = new JLabel("제품의 입력 : ");
		jl1.setFont(new Font("맑은고딕", Font.BOLD, 15));
		TextField tfNewIceName = new TextField(10);
		tfNewIceName.setFont(new Font("맑은고딕", Font.BOLD, 15));

		// 추가 완료 버튼
		JButton finishAddMenu = new JButton("메뉴 추가");
		finishAddMenu.setBackground(Color.WHITE);
		finishAddMenu.setFont(new Font("맑은고딕", Font.BOLD, 15));

		finishAddMenu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// 창 띄움
				JOptionPane.showMessageDialog(addMenuPanel, "추가되었습니다.", "", JOptionPane.OK_OPTION);
			}
		});

		addMenuPanel.add(chooseBarButton);
		addMenuPanel.add(chooseConButton);
		addMenuPanel.add(chooseCupButton);
		addMenuPanel.add(chooseChocoButton);
		addMenuPanel.add(chooseStrawButton);
		addMenuPanel.add(chooseGreenButton);
		addMenuPanel.add(chooseBananaButton);
		addMenuPanel.add(jl1);
		addMenuPanel.add(tfNewIceName);
		addMenuPanel.add(finishAddMenu);

		return addMenuPanel;
	}
}
